/* FIT9132 2019 S2 Assignment 3 Q1-Part A ANSWERS

   Student Name: Anmol Sanjay Bagati
    Student ID: 30535808

   Comments to your marker: 
   
*/

INSERT INTO resort VALUES (1, 'Amazing Resorts', '3/9 Orrong Road','3161', 4.5, 'Y', 1, 1);
INSERT INTO resort VALUES (2, 'Natural Resorts', '241 Duke Road','3345', 3.5, 'N', 2, 3);
INSERT INTO resort VALUES (3, 'Beautiful Resorts', '4/6 City Road','3820', NULL, 'Y', 3, 3);
INSERT INTO resort VALUES (4, 'Beach Resorts', '351 Brighton St','3962', 3, 'Y', 4, 4);
INSERT INTO resort VALUES (5, 'Valley Resorts', '21 Burwood ave','3269', 4, 'N', 5, 3);
INSERT INTO resort VALUES (6, 'Sunshine Resorts', '2/5 Ontario St','2654', 4, 'N', 6, 1);
INSERT INTO resort VALUES (7, 'Springs Resorts', '76 Barley Ave','6251', 4.5, 'N', 7, 3);
INSERT INTO resort VALUES (8, 'Sink Prive Resorts', '1/11 Glen Ira','9826', 5, 'N', 8, 1);
INSERT INTO resort VALUES (9, 'Orlong Resorts', '12  Greenwood Ave','8262', 4.5, 'N', 9, 4);
INSERT INTO resort VALUES (10, 'Irish Resorts', '63 Christ Gr','9846', 4, 'N', 10, 3);

INSERT INTO cabin VALUES (1,1,1,1,'Free wifi and TV with connection. 1 Bathroom fully equiped with geyser and heater. Single Bed.');
INSERT INTO cabin VALUES (2,1,1,2,'Free wifi and TV with connection. Double bed with attached balcony.');
INSERT INTO cabin VALUES (1,2,2,4,'Free wifi and TV with connection. 2 double beds with 2 fully equiped bathrooms.');
INSERT INTO cabin VALUES (2,2,3,6,'Free wifi and TV with connection. 3 Bathrooms fully equiped with geyser and heater. 3 double beds in each room with 3 balconies attached.');
INSERT INTO cabin VALUES (1,3,1,2,'Free wifi and TV with connection. Double bed with attached balcony.');
INSERT INTO cabin VALUES (2,3,2,4,'Free wifi and TV with connection. Two double beds with 2 fully equiped bathrooms.');
INSERT INTO cabin VALUES (1,4,2,8,'Free wifi and TV with connection. 3 Bathrooms fully equiped with geyser and heater. 2 double beds in each room and a huge hall and balcony attached to the hall.');
INSERT INTO cabin VALUES (2,4,3,3,'Free wifi and TV with connection. 2 Bathroom fully equiped with geyser and heater. 3 single beds in each room and ba;cony with hall.');
INSERT INTO cabin VALUES (1,5,2,4,'Free wifi and TV with connection. 2 double beds with 2 fully equiped bathrooms.');
INSERT INTO cabin VALUES (2,5,3,6,'Free wifi and TV with connection. 3 Bathrooms fully equiped with geyser and heater. 3 double beds in each room with 3 balconies attached.');
INSERT INTO cabin VALUES (1,6,1,2,'Free wifi and TV with connection. Double bed with attached balcony.');
INSERT INTO cabin VALUES (2,6,2,4,'Free wifi and TV with connection. 2 double beds with 2 fully equiped bathrooms.');
INSERT INTO cabin VALUES (1,7,3,6,'Free wifi and TV with connection. 3 Bathrooms fully equiped with geyser and heater. 3 double beds in each room with 3 balconies attached.');
INSERT INTO cabin VALUES (2,7,4,8,'Free wifi and TV with connection. 4 Bathrooms fully equiped with geyser and heater. 2 huge halls and a loby upfront with a car park in front of the cabin');
INSERT INTO cabin VALUES (1,8,2,4,'Free wifi and TV with connection. 2 double beds with 2 fully equiped bathrooms.');
INSERT INTO cabin VALUES (2,8,1,2,'Free wifi and TV with connection. Double bed with attached balcony.');
INSERT INTO cabin VALUES (1,9,3,6,'Free wifi and TV with connection. 3 Bathrooms fully equiped with geyser and heater. 3 double beds in each room with 3 balconies attached.');
INSERT INTO cabin VALUES (2,9,2,2,'Free wifi and TV with connection. 1 Bathroom fully equiped with geyser and heater. 2 single beds in each room');
INSERT INTO cabin VALUES (1,10,1,1,'Free wifi and TV with connection. 1 Bathroom fully equiped with geyser and heater. Single Bed.');
INSERT INTO cabin VALUES (2,10,2,6,'Free wifi and TV with connection. 3 Bathrooms (2 attached and 1 common) fully equiped with geyser and heater. Rooms come with a single bed and a doublebed.');

INSERT INTO booking VALUES (1,TO_DATE('01/01/2019','dd/mm/yyyy'),TO_DATE('02/01/2019','dd/mm/yyyy'),2,1,400,1,1,2);
INSERT INTO booking VALUES (2,TO_DATE('01/01/2019','dd/mm/yyyy'),TO_DATE('03/01/2019','dd/mm/yyyy'),3,1,550,2,2,3);
INSERT INTO booking VALUES (3,TO_DATE('04/01/2019','dd/mm/yyyy'),TO_DATE('09/01/2019','dd/mm/yyyy'),1,1,500,3,2,1);
INSERT INTO booking VALUES (4,TO_DATE('05/01/2019','dd/mm/yyyy'),TO_DATE('07/01/2019','dd/mm/yyyy'),2,1,400,4,1,5);
INSERT INTO booking VALUES (5,TO_DATE('07/01/2019','dd/mm/yyyy'),TO_DATE('10/01/2019','dd/mm/yyyy'),4,4,1000,5,2,7);
INSERT INTO booking VALUES (6,TO_DATE('11/01/2019','dd/mm/yyyy'),TO_DATE('14/01/2019','dd/mm/yyyy'),2,2,700,6,1,2);
INSERT INTO booking VALUES (7,TO_DATE('12/01/2019','dd/mm/yyyy'),TO_DATE('15/01/2019','dd/mm/yyyy'),4,3,780,7,2,7);
INSERT INTO booking VALUES (8,TO_DATE('20/01/2019','dd/mm/yyyy'),TO_DATE('22/01/2019','dd/mm/yyyy'),1,0,200,8,1,1);
INSERT INTO booking VALUES (9,TO_DATE('26/01/2019','dd/mm/yyyy'),TO_DATE('27/01/2019','dd/mm/yyyy'),1,0,150,9,1,10);
INSERT INTO booking VALUES (10,TO_DATE('30/01/2019','dd/mm/yyyy'),TO_DATE('1/02/2019','dd/mm/yyyy'),2,1,400,10,1,2);
INSERT INTO booking VALUES (11,TO_DATE('01/02/2019','dd/mm/yyyy'),TO_DATE('06/01/2019','dd/mm/yyyy'),4,0,800,1,1,5);
INSERT INTO booking VALUES (12,TO_DATE('05/02/2019','dd/mm/yyyy'),TO_DATE('09/02/2019','dd/mm/yyyy'),3,3,900,2,2,5);
INSERT INTO booking VALUES (13,TO_DATE('08/02/2019','dd/mm/yyyy'),TO_DATE('11/02/2019','dd/mm/yyyy'),1,0,300,3,1,1);
INSERT INTO booking VALUES (14,TO_DATE('11/02/2019','dd/mm/yyyy'),TO_DATE('14/02/2019','dd/mm/yyyy'),4,4,860,4,2,7);
INSERT INTO booking VALUES (15,TO_DATE('14/02/2019','dd/mm/yyyy'),TO_DATE('16/02/2019','dd/mm/yyyy'),3,2,600,5,1,7);
INSERT INTO booking VALUES (16,TO_DATE('17/02/2019','dd/mm/yyyy'),TO_DATE('22/02/2019','dd/mm/yyyy'),3,0,400,6,2,4);
INSERT INTO booking VALUES (17,TO_DATE('26/02/2019','dd/mm/yyyy'),TO_DATE('02/03/2019','dd/mm/yyyy'),2,0,100,7,2,1);
INSERT INTO booking VALUES (18,TO_DATE('03/03/2019','dd/mm/yyyy'),TO_DATE('05/03/2019','dd/mm/yyyy'),2,1,370,8,1,8);
INSERT INTO booking VALUES (19,TO_DATE('09/03/2019','dd/mm/yyyy'),TO_DATE('12/03/2019','dd/mm/yyyy'),7,1,910,9,1,4);
INSERT INTO booking VALUES (20,TO_DATE('14/03/2019','dd/mm/yyyy'),TO_DATE('18/03/2019','dd/mm/yyyy'),4,1,525,2,2,5);
INSERT INTO booking VALUES (21,TO_DATE('17/03/2019','dd/mm/yyyy'),TO_DATE('22/03/2019','dd/mm/yyyy'),1,1,230,1,2,1);
INSERT INTO booking VALUES (22,TO_DATE('24/03/2019','dd/mm/yyyy'),TO_DATE('29/03/2019','dd/mm/yyyy'),3,2,440,5,2,5);
INSERT INTO booking VALUES (23,TO_DATE('05/04/2019','dd/mm/yyyy'),TO_DATE('08/04/2019','dd/mm/yyyy'),3,1,530,3,1,5);
INSERT INTO booking VALUES (24,TO_DATE('26/05/2019','dd/mm/yyyy'),TO_DATE('02/05/2019','dd/mm/yyyy'),1,0,190,4,1,10);
INSERT INTO booking VALUES (25,TO_DATE('06/06/2019','dd/mm/yyyy'),TO_DATE('08/05/2019','dd/mm/yyyy'),1,2,250,7,2,6);


INSERT INTO review VALUES (1,'Visited this hotel as part of family trip. Simple, clean hotel. Really helpful and friendly staff and fabulous top garden. Had a great dinner and drinks beside the fire pits whilst watching the sun go down over beautiful views.',TO_DATE('02/02/2019','dd/mm/yyyy'),4,10,2);
INSERT INTO review VALUES (2,'The staff was extremely friendly, the restaurant very flexible (appreciate this!) and the restaurant supervisor deserves a special thanks.',TO_DATE('03/01/2019','dd/mm/yyyy'),5,1,2);
INSERT INTO review VALUES (3,'The scenery was beautiful and it was a relieve to walk in such a quiet and peaceful environment. The natural bath on the end was a great way to end the trekking. ',TO_DATE('10/01/2019','dd/mm/yyyy'),4,3,1);
INSERT INTO review VALUES (4,'Great hotel.i was stayed last month.it was a wonderful trip. staff were very polite and helpful.food was very delicious and I love it.thank you for everything.i hopes come back again',TO_DATE('07/01/2019','dd/mm/yyyy'),4,4,5);
INSERT INTO review VALUES (5,'Hotel itself is a reminiscence of colonial period. Garden was very well maintained. There us a small play area for kids too.',TO_DATE('10/01/2019','dd/mm/yyyy'),4,5,7);
INSERT INTO review VALUES (6,'Excellent stay with good room service and a beatutiful scenery. ',TO_DATE('15/01/2019','dd/mm/yyyy'),4,7,7);
INSERT INTO review VALUES (7,'Could have been better. Rooms and location was good, but the staff was not as expected. They were rude and ignorant.',TO_DATE('28/01/2019','dd/mm/yyyy'),2,9,10);
INSERT INTO review VALUES (8,'Good stay. Reasonably priced and good quality food with prompt service.',TO_DATE('1/02/2019','dd/mm/yyyy'),4,10,2);
INSERT INTO review VALUES (9,'Quality of stay was average for the price charged. Also, some hidden charges were revealed later. ',TO_DATE('9/02/2019','dd/mm/yyyy'),3,2,5);
INSERT INTO review VALUES (10,'Good and quite stay. Very peaceful. ',TO_DATE('14/02/2019','dd/mm/yyyy'),4,4,7);
INSERT INTO review VALUES (11,'Great atmosphere and good staff response. Very friendly and Helpful. ',TO_DATE('22/02/2019','dd/mm/yyyy'),4,6,4);
INSERT INTO review VALUES (12,'Horrible staff and rude back-answering room service. Nightmare stay. ',TO_DATE('02/03/2019','dd/mm/yyyy'),1,7,1);
INSERT INTO review VALUES (13,'Very bad experience and terrible room service. Chutiya staff. ',TO_DATE('12/03/2019','dd/mm/yyyy'),3,9,4);
INSERT INTO review VALUES (14,'Great stay, friendly staff and beautiful location. The rooms were clean and tidy. ',TO_DATE('18/03/2019','dd/mm/yyyy'),4,2,5);
INSERT INTO review VALUES (15,'lovely stay with peaceful and quite secluded hotel location. Rooms were neat and tidy with good and fast room service.',TO_DATE('08/04/2019','dd/mm/yyyy'),4,3,5);

commit;